-- phpMyAdmin SQL Dump
-- version 4.0.4.2
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Сен 03 2014 г., 07:11
-- Версия сервера: 5.6.13
-- Версия PHP: 5.4.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `orders`
--
CREATE DATABASE IF NOT EXISTS `orders` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `orders`;

-- --------------------------------------------------------

--
-- Структура таблицы `order_table`
--

CREATE TABLE IF NOT EXISTS `order_table` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fio` varchar(50) COLLATE utf8_bin NOT NULL,
  `organization` varchar(512) COLLATE utf8_bin NOT NULL,
  `bik` int(11) NOT NULL,
  `inn` int(11) NOT NULL,
  `account` int(11) NOT NULL,
  `comment` varchar(2048) COLLATE utf8_bin NOT NULL,
  `product` varchar(512) COLLATE utf8_bin NOT NULL,
  `quantity` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=13 ;

--
-- Дамп данных таблицы `order_table`
--

INSERT INTO `order_table` (`id`, `fio`, `organization`, `bik`, `inn`, `account`, `comment`, `product`, `quantity`, `date`) VALUES
(12, 'Иван', 'Карусель', 11, 11, 11, '23', 'Другие продукты Vipnet', 5, '2014-09-02 14:52:22');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
